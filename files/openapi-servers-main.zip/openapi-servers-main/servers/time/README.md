# 🕒 Time Tool Server

Blazingly fast time API server ⚡️

## 🚀 Quickstart

```bash
git clone https://github.com/open-webui/openapi-servers
cd openapi-servers/servers/time
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --reload
```

You're live. ⏱️📡